﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cooking_Program
{
    class Client
    {
        public int Id { get; set; }
        public string userName { get; set; }
        public string userPhone { get; set; }
        public int amount { get; set; }
        public int price { get; set; }
        public DateTime dateTime { get; set; }
    }
}
