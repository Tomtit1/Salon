﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cooking_Program
{
    public partial class MainForm : Form
    {
        SqlCommand cmd;
        SqlConnection con;
        
        public MainForm()
        {
            InitializeComponent();
        }


        #region FORM ACTIONS

        

        //CLOSE FORM==========================================================================================
        private void label4_Click(object sender, EventArgs e)
        {
            Close();
        }
        
        //MINIMISE FORM=======================================================================================
        private void label5_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void panel3_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button != MouseButtons.Left)
            {
                return;
            }
            downPoint = new Point(e.X, e.Y);
        }

        private void panel3_MouseMove(object sender, MouseEventArgs e)
        {
            if (downPoint == Point.Empty)
            {
                return;
            }
            Point location = new Point(
                this.Left + e.X - downPoint.X,
                this.Top + e.Y - downPoint.Y);
            this.Location = location;
        }

        private void panel3_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button != MouseButtons.Left)
            {
                return;
            }
            downPoint = Point.Empty;
        }
        public Point downPoint = Point.Empty;
        #endregion


        // КНОПКА ДОБАВИТЬ НОВУЮ УСЛУГУ
        private void btn1_Click(object sender, EventArgs e)
        {
            int price1;
            string sqCon = @"Data Source=SQL6003.myASP.NET;Initial Catalog=DB_A29BBD_magregar;User Id=DB_A29BBD_magregar_admin; Password=2187ZtL11v15ZsCQq;";


            if(txtField1.Text == null || txtField1.Text =="")
            {
                MessageBox.Show("Введите Имя");
                return;
            }

            if (txtField2.Text == null || txtField2.Text == "")
            {
                MessageBox.Show("Введите Номер Телефона");
                return;
            }

            if (cbTypes.SelectedItem == "Стрижка длинные волосы 20 р.")
            {
                price1 = 20;
               
            }
            else if (cbTypes.SelectedItem == "Стрижка средние волосы 18 р.")
            {
                price1 = 18;
            }
            else if (cbTypes.SelectedItem == "Стрижка короткие волосы 15 р.")
            {
                price1 = 15;
            }
            else
            {
                MessageBox.Show("Выберите Услугу");
                price1 = 0;
                return;
                
            }

            MessageBox.Show("Уважаемый(ая) "+txtField1.Text+Environment.NewLine+
                txtField2.Text+ Environment.NewLine+
                "Ваша Услуга "+cbTypes.SelectedItem);

            // МОДЕЛЬ КЛИЕНТА
            Client client = new Client();
            client.amount = 1;
            client.dateTime = DateTime.Now;
            client.price = price1;
            client.userName = txtField1.Text;
            client.userPhone = txtField2.Text;


            //======================================

            con = new SqlConnection(sqCon);
            con.Open();

            cmd = new SqlCommand("INSERT INTO [Clients]([userName],[userPhone],[amount],[price],[dateTime]) VALUES(@userName,@userPhone,@amount,@price,@dateTime)", con);
            cmd.Parameters.Add("@userName", client.userName);
            cmd.Parameters.Add("@userPhone", client.userPhone);
            cmd.Parameters.Add("@amount",client.amount);
            cmd.Parameters.Add("@price", client.price);
            cmd.Parameters.Add("@dateTime", client.dateTime);
            cmd.ExecuteNonQuery();

            con.Close();
            MessageBox.Show("Done)");



        }

        // КНОПКА БУДЕТ ОТОБРАЖАТЬ ВСЕХ КЛИЕНТОВ В DataGridView
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string sqCon = @"Data Source=SQL6003.myASP.NET;Initial Catalog=DB_A29BBD_magregar;User Id=DB_A29BBD_magregar_admin; Password=2187ZtL11v15ZsCQq;";

                con = new SqlConnection(sqCon);
                con.Open();
                var select = "SELECT * FROM Clients";
                var dataAdapter = new SqlDataAdapter(select, con);

                var commandBuilder = new SqlCommandBuilder(dataAdapter);
                var ds = new DataSet();
                dataAdapter.Fill(ds);
                dataGridView1.ReadOnly = true;
                dataGridView1.DataSource = ds.Tables[0];
            }
            catch
            {
                MessageBox.Show("Ошибка получения списка");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int price1;
            string sqCon = @"Data Source=SQL6003.myASP.NET;Initial Catalog=DB_A29BBD_magregar;User Id=DB_A29BBD_magregar_admin; Password=2187ZtL11v15ZsCQq;";


            if (txtField1.Text == null || txtField1.Text == "")
            {
                MessageBox.Show("Введите Имя");
                return;
            }

            if (txtField2.Text == null || txtField2.Text == "")
            {
                MessageBox.Show("Введите Номер Телефона");
                return;
            }

            if (cbTypes.SelectedItem == "Стрижка длинные волосы 20 р.")
            {
                price1 = 20;

            }
            else if (cbTypes.SelectedItem == "Стрижка средние волосы 18 р.")
            {
                price1 = 18;
            }
            else if (cbTypes.SelectedItem == "Стрижка короткие волосы 15 р.")
            {
                price1 = 15;
            }
            else
            {
                MessageBox.Show("Выберите Услугу");
                price1 = 0;
                return;

            }

            MessageBox.Show("Уважаемый(ая) " + txtField1.Text + Environment.NewLine +
                txtField2.Text + Environment.NewLine +
                "Ваша Услуга " + cbTypes.SelectedItem);


            // ========ДОБАВЬТЕ БИБЛИОТЕКУ Adobe InDesign CSx Type Library И РАСКОМЕНТИТЕ КОД НИЖЕ ===============

               // InDesign.Application app =
               // (InDesign.Application)COMCreateObject("InDesign.Application");
               // InDesign.Document doc = app.ActiveDocument;
               // InDesign.Page page = (InDesign.Page)doc.Pages[1]; 
               // InDesign.TextFrame frame = (InDesign.TextFrame)page.TextFrames[1];
               // frame.Contents = "Уважаемый(ая) " + txtField1.Text + Environment.NewLine +
               // txtField2.Text + Environment.NewLine +
               // "Ваша Услуга " + cbTypes.SelectedItem;
           


                MessageBox.Show("Добавьте библиотеку  - Adobe InDesign CSx Type Library"+Environment.NewLine+
                    "И уберите коментарии из данного кода: "+Environment.NewLine+
                    
                    "InDesign.Application app ="+Environment.NewLine+
                "(InDesign.Application)COMCreateObject('InDesign.Application');"+
                "InDesign.Document doc = app.ActiveDocument;"+
                "InDesign.Page page = (InDesign.Page)doc.Pages[1];"+ 
                "InDesign.TextFrame frame = (InDesign.TextFrame)page.TextFrames[1];"+
                 "frame.Contents = 'text'");
                // Adobe InDesign CSx Type Library
            
        }

        private void btn2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("В Разработке");
        }

        
    }
}
